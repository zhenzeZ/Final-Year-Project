# Integration tests

This directory regroups high level tests, often testing both the C++ code and
its Python bindings.

